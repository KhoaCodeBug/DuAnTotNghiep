# Indoor Fog Surface Prototype — V1 user review and V2 handoff

Date: 2026-08-31

## Status labels

- **Confirmed by user/manual observation:** V1 is broadly acceptable as a first prototype, and the user wants the feature continued.
- **Observed defects:** light-to-dark boundaries are still too hard compared with the approved concept; approaching some walls produces black streaks; moving close to walls can make those streaks flicker continuously.
- **Not yet diagnosed:** the exact source of the streak/flicker. The still images prove the artifact exists but cannot identify its temporal trigger.
- **Not accepted as stable:** V1 has automated coverage and a runtime screenshot set, but the user has explicitly found visual regressions. Do not promote it beyond the sample house yet.

User evidence is preserved in `V1_UserReview_20260831/`:

- `user-hard-transition.png`
- `user-near-wall-black-streak.png`

The approved visual target and user-marked concept remain in `../IndoorFogConcept_20260831/`.

## Required behavior for V2

1. Keep the surface reveal on visible wall, picture, shelf and cabinet faces.
2. Make the light-to-dark transition visibly smoother and closer to the approved concept.
3. Remove black streaks near walls and stop continuous flicker while the Player approaches or moves parallel to a wall.
4. Preserve occlusion: smoothing must not reveal floor, actors or objects behind a closed wall.
5. Continue with one sample house only until the result is visually accepted and measured.
6. After each isolated implementation step, capture a real Unity Game View image at fixed poses and compare it against both the approved concept and the V1 defect images. Record the mismatch honestly.

## Investigation order

Do not begin by adding a broad blur. First stabilize the visibility signal; otherwise blur can hide the shape while preserving temporal flicker.

1. Reproduce near each reported wall at fixed camera/zoom and record the position, facing, flashlight state and time of day. Capture a short sequence or multiple consecutive frames, not only one screenshot.
2. Determine whether the instability comes from the original 15 Hz ray fan/collider hit distance, discontinuous surface-atlas foot projection, point-sampled atlas lookup, disagreement between original and projected visibility combined with `max`, camera sub-pixel movement, or more than one factor. These are hypotheses, not confirmed causes.
3. Fix the unstable source with a bounded rule such as stable sampling, epsilon/hysteresis or temporal interpolation only after identifying which value flips. Do not patch individual wall coordinates.
4. Add spatial feathering that stays on the visible side of occluders. Compare the feather width and early darkening on the right wall to the approved concept.
5. Repeat day/night, flashlight on/off, approach/parallel movement, left/right facing, exit/return, prototype disable and the existing performance A/B/A measurement.

## Quality gates

- Do not change scenes or prefabs for the sample experiment unless inspection proves it is necessary and the user approves the scope.
- Do not extend to other houses before this house passes the user review.
- Keep Fog presentation local; do not add Fusion replicated state/RPC for the visual mask.
- Treat screenshot comparison as evidence, not pixel-perfect equivalence. Capture before/after with the same pose and Game View size.
- If two or three focused iterations still require house-specific exceptions, a renderer rewrite, or introduce visibility leaks, stop and discuss whether to abandon this enhancement rather than expanding complexity.
- Re-run compile/Console, the existing 44 Editor tests, the 5 relevant PlayMode tests, and focused runtime movement checks after material changes. Automated tests do not replace user acceptance.
- Re-measure CPU/GPU. V1 measured roughly +0.08 to +0.23 ms median GPU in the existing A/B/A run, with noisy CPU values; do not promise 60 FPS.

## Safety and Git

- Stable pre-prototype checkpoint: `codex/checkpoint-vision-menu-stable-20260831` at `ddf440424`.
- Working branch at handoff: `codex/restore-indoor-vision-20260831`, HEAD `ddf440424`, dirty local prototype and QA artifacts, not committed or pushed.
- Do not reset, clean, restore or overwrite teammate/user changes. No push without explicit permission or successful user acceptance under repository rules.
- Canonical history: `CODEX_PROJECT_WORK_LOG.md`. Verify repository and Unity state before trusting this handoff.

## Next-session startup

1. Read `AGENTS.md`, the three Unity project skills, the latest entries in `CODEX_PROJECT_WORK_LOG.md`, this file, and `README.md` in this directory.
2. Inspect Git status/diff and verify Unity Editor/Console state.
3. Preserve the V1 implementation and evidence before editing.
4. Reproduce and instrument the wall flicker first. Do not claim a root cause from the screenshots alone.
5. Work in isolated steps. After every step, capture real in-game evidence and append the comparison and remaining defects to this handoff/work log.

